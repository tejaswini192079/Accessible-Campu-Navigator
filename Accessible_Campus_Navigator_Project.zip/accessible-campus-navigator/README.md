# PathAble — Accessible Campus Navigator

**M9 project prototype**

PathAble is an indoor-outdoor campus navigation prototype designed to make campus journeys easier for wheelchair users and visually impaired students.

## Features
- Fastest and step-free route choices.
- Landmark-based, screen-reader-friendly directions.
- Optional spoken directions using the browser's text-to-speech feature.
- Report a broken lift, blocked ramp or path issue.
- Demo rerouting after a lift issue is reported.
- Three sample campus buildings: Academic Block, Central Library and Innovation Lab.
- Responsive layout for desktop and mobile.

## Run the project
1. Download or clone this repository.
2. Keep `index.html`, `styles.css` and `script.js` in the same folder.
3. Open `index.html` in a browser.
4. Choose a start point and destination, select a route and press **Find my route**.
5. Try reporting **Lift not working** to see the demo route instructions update.

## GitHub Pages
In your repository, open **Settings → Pages**. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then save. GitHub will provide the published website link after deployment.

## Important prototype note
This is a front-end demonstration with sample campus routes and sample accessibility data. It does not use live GPS, a real campus map, a connected database, or verified lift-status feeds. Reports are stored only in the current browser page session and are not sent to campus staff. Before real-world use, campus paths, ramps, lifts, entrances and directions must be surveyed and verified. A production version should connect to a backend and provide an accessible review process for reports.

## Accessibility notes
- Semantic HTML and labelled form controls.
- Keyboard-visible focus styles and a skip link.
- Route updates announced through an `aria-live` region.
- Voice directions use browser speech synthesis where supported.
- Screen-reader support depends on the device/browser settings; test with Android TalkBack and Apple VoiceOver before release.
