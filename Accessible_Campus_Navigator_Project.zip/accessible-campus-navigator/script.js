const startSelect = document.getElementById("start");
const destinationSelect = document.getElementById("destination");
const routeButtons = [...document.querySelectorAll(".route-choice")];
const routeResult = document.getElementById("routeResult");
const directionsList = document.getElementById("directionsList");
const voiceToggle = document.getElementById("voiceToggle");
let routeMode = "stepfree";
let voiceEnabled = false;
let reportedIssues = [];

const placeNames = {
  gate: "Main Campus Gate",
  buildingA: "Building A · Academic Block",
  buildingB: "Building B · Library",
  buildingC: "Building C · Innovation Lab"
};

const routeTemplates = {
  fastest: [
    "Head towards the central campus walkway.",
    "Follow the direct corridor towards your selected building.",
    "Use the nearest available entrance to reach your destination."
  ],
  stepfree: [
    "Start at your selected location and follow the wide, level campus pathway.",
    "Continue towards the clearly marked accessible entrance.",
    "Use the ramp or a lift confirmed as available. Avoid all stairs.",
    "Follow the corridor landmarks to reach your destination."
  ]
};

function issueAffectsLift() {
  return reportedIssues.some(issue => issue.type === "Lift not working");
}

function buildDirections(mode, start, destination) {
  const from = placeNames[start];
  const to = placeNames[destination];
  let steps = [...routeTemplates[mode]];
  if (mode === "stepfree" && issueAffectsLift()) {
    steps = [
      `Start at ${from}.`,
      "Follow the wide, level outdoor pathway towards the alternative accessible entrance.",
      "Avoid the reported lift. In this demo, use the mapped ramp route instead.",
      `Follow the corridor signs towards ${to}.`
    ];
  } else {
    steps.unshift(`Start at ${from}.`);
    steps.push(`You have reached ${to}.`);
  }
  return steps;
}

function updateRoute() {
  const start = startSelect.value;
  const destination = destinationSelect.value;
  if (start === destination) {
    routeResult.classList.remove("show");
    alert("Please choose two different locations.");
    return;
  }
  const steps = buildDirections(routeMode, start, destination);
  document.getElementById("routeSummary").textContent = `${placeNames[start]} → ${placeNames[destination]}`;
  document.getElementById("routeTime").textContent = routeMode === "fastest" ? "5 min (demo)" : "8 min (demo)";
  document.getElementById("routeAccess").textContent = routeMode === "stepfree" ? "Avoids stairs" : "Check access points";
  document.getElementById("routeVia").textContent = issueAffectsLift() && routeMode === "stepfree" ? "Alternative ramp route" : routeMode === "stepfree" ? "Ramp and level corridor" : "Central walkway";
  directionsList.innerHTML = "";
  steps.forEach(step => {
    const li = document.createElement("li");
    li.textContent = step;
    directionsList.appendChild(li);
  });
  routeResult.classList.add("show");
  document.getElementById("routePath").setAttribute("d", routeMode === "stepfree" ? "M75 300 L190 300 L190 175 L405 175" : "M75 300 L280 300 L405 175");
  if (voiceEnabled) speak(steps.join(" "));
}

routeButtons.forEach(button => {
  button.addEventListener("click", () => {
    routeMode = button.dataset.mode;
    routeButtons.forEach(item => {
      const selected = item === button;
      item.classList.toggle("selected", selected);
      item.setAttribute("aria-pressed", String(selected));
    });
  });
});

document.getElementById("findRoute").addEventListener("click", updateRoute);

function speak(text) {
  if (!("speechSynthesis" in window)) {
    alert("Sorry, spoken directions are not supported in this browser. Please use the text directions.");
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 0.92;
  utterance.pitch = 1;
  window.speechSynthesis.speak(utterance);
}

voiceToggle.addEventListener("click", () => {
  voiceEnabled = !voiceEnabled;
  voiceToggle.setAttribute("aria-pressed", String(voiceEnabled));
  document.getElementById("voiceState").textContent = voiceEnabled ? "On" : "Off";
  if (!voiceEnabled && "speechSynthesis" in window) window.speechSynthesis.cancel();
  if (voiceEnabled && routeResult.classList.contains("show")) {
    speak([...directionsList.querySelectorAll("li")].map(item => item.textContent).join(" "));
  }
});

document.getElementById("speakDirections").addEventListener("click", () => {
  const text = [...directionsList.querySelectorAll("li")].map(item => item.textContent).join(" ");
  speak(text);
});

document.getElementById("reportForm").addEventListener("submit", event => {
  event.preventDefault();
  const location = document.getElementById("issueLocation").value;
  const type = document.getElementById("issueType").value;
  const details = document.getElementById("issueDetails").value.trim();
  reportedIssues.push({ location, type, details });
  const message = document.getElementById("formMessage");
  message.textContent = `Thank you. Your "${type}" report for ${location} has been added to this demo. It is marked as awaiting staff verification.`;
  if (type === "Lift not working") {
    message.textContent += " Step-free demo directions will now avoid the lift and suggest the alternative ramp route.";
  }
  event.target.reset();
  if (routeResult.classList.contains("show")) updateRoute();
});

document.getElementById("destination").addEventListener("change", () => {
  // The student can change the destination and press Find my route to refresh directions.
});

// Show a useful sample route when the page first opens.
updateRoute();
